# tang_nano_9k_pcb
Sipeed Tang Nano 9K  Carrier board design (WIP)

This board is designed to add extra interfaces to the Tang Nano 9K, such as:

- SPI Ethernet (W5500)
- Trackball
- PS/2 Keyboard
- Audio (I2S DAC)

Mini-DIN6 footprint (PS/2) provided by
https://github.com/4x1md/kicad_libraries/tree/master/Custom_Footprints.pretty
